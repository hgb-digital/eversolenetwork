extends Node2D

func start(title, score, rank, pr):
	var f = load("res://ENET/scripts/enet_functions.gd")
	var _internal = f.InternalFunctions.new()
	_internal.load_images(self)
	get_node('title').text = title
	get_node('score').text = str(score)
	if int(rank) < 4:
		get_node('ranking/top_ranking').play(str(rank))
		get_node('ranking/number').hide()
	else:
		get_node('ranking/top_ranking').hide()
		get_node('ranking/number').text = "#" + str(rank)
		
	if pr:
		get_node('ranking/pr').show()
	else:
		get_node('ranking/pr').hide()

func finished():
	queue_free()
