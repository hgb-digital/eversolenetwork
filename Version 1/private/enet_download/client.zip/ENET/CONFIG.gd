
class Config:
	var server_ip = "eversole.network"
	var game_id = null #INSERT ID HERE
	var game_version = null #INSERT Version HERE
	var game_password = null #INSERT Password HERE
